# wtLogon.pl

##########################################################
##
##		LOGON   				
##
##########################################################
# ----------------------------------------------------------------------------------------------
sub html_login_form {

&html_print_headers;
print qq|
<HTML><HEAD><TITLE>LETS webtool</TITLE></HEAD>
<BODY TEXT="black" BGCOLOR="#999999" LINK="#00cc00" VLINK="#00cc00" ALINK="#00cc00" onLoad="document.form1.userid.focus()">

<form action="$db_script_url" method="post" name="form1">
	<input type=hidden name="db" value="$db_setup">
	<input type=hidden name="uid" value="$db_uid">

	<table align=center bgcolor="white" border=0 cellspacing=1 cellpadding=4 width=600>
		<tr><td bgcolor="#003300"><$fontSmallWhite>Webtool version $version&nbsp;</font></td></tr>
		<tr>
			<td align=right bgcolor="#00cc00">
				<$fontLargeWhite>Logon to </font>
				|; print &buildSystemList("sys"); print qq|
			</td>
		</tr>
		<tr>
			<td align=right bgcolor="#cccccc">
				<$fontBlue>
					<b>User ID&nbsp;</b><input type="TEXT" name="userid" size=14>
				</FONT>
			</td>
		</tr>
		<tr>
			<td align=right bgcolor="#cccccc">
				<$fontBlue>
					<b>Password&nbsp;</b><input type="PASSWORD" name="pw" size=14>
				</FONT>
			</td>
		</tr>
		<tr>
			<td align=right>
				<input type="SUBMIT" name="login" value="  Logon  ">
			</td>
		</tr>
		<tr>
			<td bgcolor="white">
				<$font>
					<font color="#00cc00"><font size=3><b>The LETS Webtool</b></font></font>
					<br><br>
					The webtool is free web-based software that was written to allow community 
					currency groups to add an internet dimension to their LETS, HOURS, or Time 
					Dollar systems. The software provides an option to link multiple LETS 
					together in a regional trading network, using the internet as the vehicle. 
					A single LETS may also use the software on their own. This copy is a demo,
					through which you can log onto Default LETS using <b>admin/admin</b> as user
					ID and password, to see how the software works. For more information, see:

					|; $downloadURL="http://lentils.imagineis.com/webtool"; print qq|
					<ul>
						<li><a href="$downloadURL/download.htm"><b>Installing the Webtool on Your Server</b></a></li>
						<li><a href="$downloadURL/LETSwebtool.zip"><b>Download Source Code</b></a></li>
						<li><a href="$downloadURL/help.htm"><b>User Manual</b></a></li>
					</ul>
				</font>
			</td>
		</tr>
	</table>
	<BR>
</form>
</BODY>
</HTML>
|;
}

sub demoBlurb {
print qq|
|;
}

##########################################################
## 
##		MAIN MENU AFTER LOGON
##
##########################################################
sub html_home {

&html_print_headers;
print  qq|
<html><head><title></title></head>
<body BGCOLOR="#C0C0C0" LINK="#FFFFFF" VLINK="#FFFFFF" ALINK="#FFFFFF">
<table border=1 bgcolor="#FFFFFF" cellpadding=5 cellspacing=3 width=640 align=center valign=top>
    <tr>
		<td>|;
			# We know we have the system ID at this point: $in{'sys'}. Get the system name.

			open (SYSTEMS, "<systems.db") or &cgierr ("Unable to open systems file.\nReason: $!");
			if ($db_use_flock) { flock(SYSTEMS, 1); }
			$found = 0;
			LINE: while (<SYSTEMS>) {		
				next if /^#/; 		# ignore comment lines
				next if /^\s*$/;	# ignore blank lines
				$line = $_;	chomp ($line);		
				@fields = &split_decode ($line);		# Build an array of fields.
				if ($fields[0] eq "$in{'sys'}") { 
					# Found the system record that matches system ID from Login.
					$sysName = $fields[2]; 
					$sysID = $in{'sys'};
					$found = 1; 
				}
			}
			close SYSTEMS;

			# Revert to the Demo if the system was not found.
			if (!$found) { 
				$sysID = -1; 
				$sysName = "Demo"; 
			}
			print qq|
		    <$fontLarge2>$sysName</FONT>
			<BR><$fontBlue>LETS webtool $version: <b>$db_userid</B> logged on.
			<BR><BR><BR><BR><BR>
			|; &html_footer; print qq|
		</td>
    </tr>
</table> 
</body>
</html>
|;
}

##########################################################
##
##		LOGON FAILURE
##
##########################################################
sub html_login_failure {
# ----------------------------------------------------------------------------------------------
# There was an error logging in. The error message is stored in $message.

my ($message) = $_[0];
	
&html_print_headers;
print qq|
<html><head><title>$systemName: Logon Error.</title></head>
<body BGCOLOR="#C0C0C0" text="#000000" LINK="#FFFFFF" VLINK="#FFFFFF" ALINK="#FFFFFF" onLoad="document.form1.userid.focus()">

<form action="$db_script_url" method="post" name="form1">
	<input type=hidden name="db" value="$db_setup">
	<input type=hidden name="uid" value="$db_uid">	
	<table border=1 bgcolor="#FFFFFF" align=center cellpadding=5 cellspacing=3 width=640 valign=top>
		<tr>
			<td>
				<p><$fontLarge>Logon Error</font><br>
				<$font>
					Oops, there was a problem logging into the system: 
					<font color=red><b>$message</b>.</font>
					<br>Please try logging in again.
				</font>
				<p>
				<table border=0 align=right width=388 cellspacing=1 cellpadding=4>
					<tr>
						<td bgcolor="white" align=left>
							<$fontLarge>Logon to</font>
							|; print &buildSystemList("sys"); print qq|
						</td>
					</tr>
					<tr>
						<td align=right bgcolor="#cccccc">
							<$fontBlue><b>User ID </b></FONT>
							<input type="TEXT" name="userid" value="$in{'userid'}">
						</td>
					</tr>
					<tr>
						<td align=right bgcolor="#cccccc">
							<$fontBlue><b>Password </b></FONT>
							<input type="PASSWORD" name="pw" value="$in{'pw'}">
						</td>
					</tr>
					<tr>
						<td align=right bgcolor="#009900">
							<input type="SUBMIT" name="login" value="Logon">
							<INPUT TYPE="SUBMIT" NAME="logoff" VALUE="Cancel">
						</td>
					</tr>
				</table>		
			</td>
		</tr>
	</table>
</form>
</body>
</html>
|;
}
1;
